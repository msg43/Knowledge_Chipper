"""
Voice Fingerprinting Test Command

CLI command for testing and demonstrating the advanced voice fingerprinting system.
"""

import sys
from pathlib import Path
from typing import Optional

import click

from ..logger import get_logger
from ..voice import (
    create_speaker_verification_service,
    create_voice_fingerprint_processor,
    load_audio_for_voice_processing,
)
from ..voice.accuracy_testing import (
    VoiceAccuracyTester,
    run_comprehensive_accuracy_test,
)

logger = get_logger(__name__)


@click.group()
def voice():
    """Voice fingerprinting and speaker verification commands."""


@voice.command()
@click.argument('audio_file', type=click.Path(exists=True, path_type=Path))
@click.option('--device', default='auto', help='Device to use (auto, cpu, mps, cuda)')
def extract_fingerprint(audio_file: Path, device: str):
    """Extract voice fingerprint from an audio file."""
    try:
        click.echo(f"🎙️ Extracting voice fingerprint from: {audio_file}")
        
        # Create processor
        processor = create_voice_fingerprint_processor(device=device)
        
        # Load audio
        audio = load_audio_for_voice_processing(audio_file)
        click.echo(f"📊 Audio loaded: {len(audio)} samples, {len(audio)/16000:.1f} seconds")
        
        # Extract fingerprint
        fingerprint = processor.extract_voice_fingerprint(audio)
        
        # Display results
        click.echo("\n✅ Voice Fingerprint Extracted:")
        for feature_type, values in fingerprint.items():
            if isinstance(values, list):
                click.echo(f"  {feature_type}: {len(values)} features")
            else:
                click.echo(f"  {feature_type}: {values}")
        
        # Show feature availability
        available_features = [k for k, v in fingerprint.items() if isinstance(v, list) and v]
        click.echo(f"\n🔍 Available features: {', '.join(available_features)}")
        
    except ImportError as e:
        click.echo(f"❌ Missing dependencies: {e}")
        click.echo("Install with: pip install -r requirements-voice.txt")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('speaker_name')
@click.argument('audio_file', type=click.Path(exists=True, path_type=Path))
@click.option('--confidence', default=0.85, help='Confidence threshold (0.0-1.0)')
def enroll_speaker(speaker_name: str, audio_file: Path, confidence: float):
    """Enroll a speaker from an audio file."""
    try:
        click.echo(f"👤 Enrolling speaker: {speaker_name}")
        click.echo(f"🎵 From audio file: {audio_file}")
        
        # Create service
        service = create_speaker_verification_service(confidence_threshold=confidence)
        
        # Enroll speaker
        success = service.enroll_speaker_from_file(speaker_name, audio_file)
        
        if success:
            click.echo(f"✅ Successfully enrolled speaker '{speaker_name}'")
            click.echo(f"🎯 Confidence threshold: {confidence}")
        else:
            click.echo(f"❌ Failed to enroll speaker '{speaker_name}'")
            sys.exit(1)
            
    except ImportError as e:
        click.echo(f"❌ Missing dependencies: {e}")
        click.echo("Install with: pip install -r requirements-voice.txt")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('speaker_name')
@click.argument('audio_file', type=click.Path(exists=True, path_type=Path))
@click.option('--start', default=0.0, help='Start time in seconds')
@click.option('--end', default=None, type=float, help='End time in seconds')
@click.option('--confidence', default=0.85, help='Confidence threshold (0.0-1.0)')
def verify_speaker(speaker_name: str, audio_file: Path, start: float, 
                  end: Optional[float], confidence: float):
    """Verify a speaker against an enrolled voice profile."""
    try:
        click.echo(f"🔍 Verifying speaker: {speaker_name}")
        click.echo(f"🎵 From audio file: {audio_file}")
        
        # Create service
        service = create_speaker_verification_service(confidence_threshold=confidence)
        
        # Create fake diarization segment for the specified time range
        audio = load_audio_for_voice_processing(audio_file)
        audio_duration = len(audio) / 16000
        
        if end is None:
            end = audio_duration
        
        diarization_segments = [{"start": start, "end": min(end, audio_duration)}]
        
        click.echo(f"⏱️ Testing segment: {start:.1f}s - {min(end, audio_duration):.1f}s")
        
        # Verify speaker
        is_match, conf_score, details = service.verify_speaker_from_segments(
            speaker_name, diarization_segments, audio_file
        )
        
        # Display results
        click.echo(f"\n🎯 Verification Result:")
        click.echo(f"  Match: {'✅ YES' if is_match else '❌ NO'}")
        click.echo(f"  Confidence: {conf_score:.3f}")
        click.echo(f"  Threshold: {confidence}")
        
        if 'segments_processed' in details:
            click.echo(f"  Segments processed: {details['segments_processed']}")
            click.echo(f"  Max confidence: {details.get('max_confidence', 0):.3f}")
            
    except ImportError as e:
        click.echo(f"❌ Missing dependencies: {e}")
        click.echo("Install with: pip install -r requirements-voice.txt")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('audio_file1', type=click.Path(exists=True, path_type=Path))
@click.argument('audio_file2', type=click.Path(exists=True, path_type=Path))
def test_similarity(audio_file1: Path, audio_file2: Path):
    """Test similarity calculation between two audio files."""
    try:
        click.echo(f"🔍 Testing similarity between:")
        click.echo(f"  File 1: {audio_file1}")
        click.echo(f"  File 2: {audio_file2}")
        
        tester = VoiceAccuracyTester()
        results = tester.test_similarity_calculation(audio_file1, audio_file2)
        
        if "error" in results:
            click.echo(f"❌ Error: {results['error']}")
            sys.exit(1)
        
        click.echo(f"\n📊 Similarity Results:")
        click.echo(f"  Overall similarity: {results['overall_similarity']:.3f}")
        click.echo(f"  Duration 1: {results['duration1']:.1f}s")
        click.echo(f"  Duration 2: {results['duration2']:.1f}s")
        
        click.echo(f"\n🔬 Feature-specific similarities:")
        for feature, similarity in results['feature_similarities'].items():
            if isinstance(similarity, float):
                click.echo(f"  {feature}: {similarity:.3f}")
            else:
                click.echo(f"  {feature}: {similarity}")
                
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('audio_file', type=click.Path(exists=True, path_type=Path))
@click.option('--runs', default=5, help='Number of test runs')
def test_consistency(audio_file: Path, runs: int):
    """Test feature extraction consistency across multiple runs."""
    try:
        click.echo(f"🧪 Testing consistency with {runs} runs on: {audio_file}")
        
        tester = VoiceAccuracyTester()
        results = tester.test_feature_extraction_consistency(audio_file, runs)
        
        if "error" in results:
            click.echo(f"❌ Error: {results['error']}")
            sys.exit(1)
        
        click.echo(f"\n⏱️ Processing Performance:")
        click.echo(f"  Average time: {results['avg_extraction_time']:.3f}s")
        click.echo(f"  Std deviation: {results['std_extraction_time']:.3f}s")
        
        click.echo(f"\n🎯 Feature Consistency:")
        for feature, data in results['feature_consistency'].items():
            if data['available']:
                consistency = data['consistency_score']
                color = "🟢" if consistency > 0.95 else "🟡" if consistency > 0.9 else "🔴"
                click.echo(f"  {color} {feature}: {consistency:.3f}")
            else:
                click.echo(f"  ⚪ {feature}: {data['reason']}")
                
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('test_data_dir', type=click.Path(exists=True, path_type=Path))
@click.option('--confidence', default=0.85, help='Confidence threshold (0.0-1.0)')
@click.option('--output', type=click.Path(path_type=Path), help='Output file for detailed results')
def test_accuracy(test_data_dir: Path, confidence: float, output: Optional[Path]):
    """Run comprehensive accuracy testing on a directory of test data."""
    try:
        click.echo(f"🎯 Running accuracy test on: {test_data_dir}")
        click.echo(f"📊 Confidence threshold: {confidence}")
        
        # Check for test configuration
        test_config = test_data_dir / "test_config.json"
        if not test_config.exists():
            click.echo(f"⚠️  No test_config.json found in {test_data_dir}")
            click.echo("Creating sample configuration...")
            
            # Create sample config
            sample_config = [
                {
                    "enrollment_audio": "speaker1_enroll.wav",
                    "test_audio": "speaker1_test.wav", 
                    "speaker_name": "Speaker1",
                    "is_same_speaker": True
                },
                {
                    "enrollment_audio": "speaker1_enroll.wav",
                    "test_audio": "speaker2_test.wav",
                    "speaker_name": "Speaker1", 
                    "is_same_speaker": False
                }
            ]
            
            with open(test_config, 'w') as f:
                import json
                json.dump(sample_config, f, indent=2)
            
            click.echo(f"📝 Sample configuration created at {test_config}")
            click.echo("Please edit this file with your actual test data and run again.")
            return
        
        # Run comprehensive test
        results = run_comprehensive_accuracy_test(test_data_dir, confidence)
        
        # Display results
        if "accuracy_test" in results:
            acc_results = results["accuracy_test"]
            if "error" not in acc_results:
                accuracy = acc_results["accuracy"]
                far = acc_results["false_acceptance_rate"]
                frr = acc_results["false_rejection_rate"]
                eer = acc_results["equal_error_rate"]
                
                click.echo(f"\n🎯 Accuracy Test Results:")
                click.echo(f"  Accuracy: {accuracy:.3f} ({accuracy*100:.1f}%)")
                click.echo(f"  False Acceptance Rate: {far:.3f}")
                click.echo(f"  False Rejection Rate: {frr:.3f}")
                click.echo(f"  Equal Error Rate: {eer:.3f}")
                click.echo(f"  Total tests: {acc_results['total_tests']}")
                
                # Color-coded accuracy assessment
                if accuracy >= 0.97:
                    click.echo("🟢 EXCELLENT: 97%+ accuracy achieved!")
                elif accuracy >= 0.95:
                    click.echo("🟡 GOOD: 95%+ accuracy achieved")
                elif accuracy >= 0.90:
                    click.echo("🟠 FAIR: 90%+ accuracy achieved")
                else:
                    click.echo("🔴 NEEDS IMPROVEMENT: <90% accuracy")
            else:
                click.echo(f"❌ Accuracy test error: {acc_results['error']}")
        
        # Save detailed results
        if output:
            with open(output, 'w') as f:
                import json
                json.dump(results, f, indent=2, default=str)
            click.echo(f"📄 Detailed results saved to: {output}")
        
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
@click.argument('audio_dir', type=click.Path(exists=True, path_type=Path))
@click.option('--segments', default='5,10,15,30', help='Comma-separated segment lengths in seconds')
def benchmark_performance(audio_dir: Path, segments: str):
    """Benchmark processing performance with different audio lengths."""
    try:
        segment_lengths = [float(s.strip()) for s in segments.split(',')]
        click.echo(f"⚡ Benchmarking performance on: {audio_dir}")
        click.echo(f"📏 Segment lengths: {segment_lengths}s")
        
        # Find audio files
        audio_files = list(audio_dir.glob("*.wav")) + list(audio_dir.glob("*.mp3"))
        if not audio_files:
            click.echo("❌ No audio files found (.wav or .mp3)")
            sys.exit(1)
        
        click.echo(f"🎵 Found {len(audio_files)} audio files")
        
        tester = VoiceAccuracyTester()
        results = tester.benchmark_performance(audio_files, segment_lengths)
        
        click.echo(f"\n⚡ Performance Benchmark Results:")
        for segment_length, metrics in results['results'].items():
            click.echo(f"\n  {segment_length} segments:")
            click.echo(f"    Avg processing time: {metrics['avg_processing_time']:.3f}s")
            click.echo(f"    Std deviation: {metrics['std_processing_time']:.3f}s")
            click.echo(f"    Min/Max time: {metrics['min_processing_time']:.3f}s / {metrics['max_processing_time']:.3f}s")
            click.echo(f"    Avg features extracted: {metrics['avg_features_extracted']:.1f}")
            click.echo(f"    Files processed: {metrics['files_processed']}")
            
    except Exception as e:
        click.echo(f"❌ Error: {e}")
        sys.exit(1)


@voice.command()
def test_dependencies():
    """Test if voice fingerprinting dependencies are available."""
    click.echo("🧪 Testing voice fingerprinting dependencies...")
    
    # Test basic imports
    try:
        click.echo("✅ librosa: Available")
    except ImportError:
        click.echo("❌ librosa: Missing")
    
    try:
        import torch
        click.echo(f"✅ torch: Available (version {torch.__version__})")
        if torch.backends.mps.is_available():
            click.echo("  🚀 MPS acceleration: Available")
        elif torch.cuda.is_available():
            click.echo("  🚀 CUDA acceleration: Available")
        else:
            click.echo("  💻 CPU only")
    except ImportError:
        click.echo("❌ torch: Missing")
    
    try:
        click.echo("✅ transformers: Available")
    except ImportError:
        click.echo("❌ transformers: Missing (wav2vec2 features unavailable)")
    
    try:
        click.echo("✅ speechbrain: Available")
    except ImportError:
        click.echo("❌ speechbrain: Missing (ECAPA features unavailable)")
    
    try:
        from ..voice import create_voice_fingerprint_processor
        processor = create_voice_fingerprint_processor()
        click.echo("✅ Voice fingerprinting module: Available")
    except Exception as e:
        click.echo(f"❌ Voice fingerprinting module: Error - {e}")
    
    click.echo("\n📋 Installation command:")
    click.echo("pip install -r requirements-voice.txt")


if __name__ == '__main__':
    voice()
