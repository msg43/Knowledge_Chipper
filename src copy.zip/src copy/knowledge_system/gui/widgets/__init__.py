"""GUI widgets for the Knowledge System."""
