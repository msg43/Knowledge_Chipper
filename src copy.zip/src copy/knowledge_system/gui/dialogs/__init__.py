"""
GUI dialogs for Knowledge Chipper.

This module contains various dialog windows and modals used throughout
the application.
"""
