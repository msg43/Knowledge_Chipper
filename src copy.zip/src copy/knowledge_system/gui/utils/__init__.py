"""GUI utilities for the Knowledge System."""
